// Artikel ini adalah contoh fiktif, bukan berita aktual.
const articles = [
  {
    category: 'Teknologi', date: '2025-03-18', title: 'Teknologi sederhana yang mengubah cara kita bekerja',
    summary: 'Berbagai alat digital membantu pekerjaan sehari-hari menjadi lebih teratur dan efisien.',
    body: ['Perkembangan teknologi menghadirkan cara baru untuk menyelesaikan pekerjaan sehari-hari. Alat pencatat, kalender digital, dan aplikasi kolaborasi dapat membantu kita mengatur prioritas.', 'Namun, teknologi paling bermanfaat ketika digunakan sesuai kebutuhan. Memilih alat yang sederhana dan mudah dipahami dapat membantu tim tetap fokus pada tujuan.'], art: 'art-tech', symbol: '01'
  },
  {
    category: 'Lingkungan', date: '2025-03-15', title: 'Langkah kecil untuk lingkungan yang lebih hijau',
    summary: 'Kebiasaan sederhana di rumah dapat menjadi awal dari perubahan yang lebih besar.',
    body: ['Mengurangi sampah, membawa botol minum sendiri, dan memilah barang yang dapat digunakan kembali adalah beberapa langkah yang bisa dilakukan setiap hari.', 'Perubahan tidak harus dimulai dari hal besar. Ketika kebiasaan baik dilakukan bersama, dampaknya dapat dirasakan oleh lingkungan sekitar.'], art: 'art-nature', symbol: '02'
  },
  {
    category: 'Gaya Hidup', date: '2025-03-12', title: 'Menemukan waktu untuk jeda di tengah kesibukan',
    summary: 'Meluangkan waktu untuk beristirahat dapat membantu menjaga keseimbangan aktivitas.',
    body: ['Di tengah jadwal yang padat, mengambil jeda sejenak dapat membantu kita kembali fokus. Berjalan kaki, membaca, atau menikmati suasana tenang adalah beberapa pilihan sederhana.', 'Setiap orang memiliki cara istirahat yang berbeda. Hal terpenting adalah menemukan rutinitas yang sesuai dan memberi ruang untuk diri sendiri.'], art: 'art-life', symbol: '03'
  },
  {
    category: 'Pendidikan', date: '2025-03-09', title: 'Belajar bersama, tumbuh bersama',
    summary: 'Diskusi dan kerja sama membuka kesempatan untuk memahami gagasan dari sudut pandang baru.',
    body: ['Belajar tidak selalu dilakukan sendirian. Melalui diskusi, peserta dapat bertukar pengalaman dan menemukan cara berbeda untuk memahami suatu topik.', 'Suasana yang terbuka dan saling menghargai juga membuat setiap orang lebih nyaman untuk bertanya dan berbagi ide.'], art: 'art-education', symbol: '04'
  },
  {
    category: 'Teknologi', date: '2025-03-06', title: 'Menjaga keamanan data dalam kehidupan digital',
    summary: 'Mengenali kebiasaan dasar yang dapat membantu melindungi akun dan informasi pribadi.',
    body: ['Kata sandi yang kuat dan unik untuk setiap akun merupakan salah satu dasar keamanan digital. Pengelola kata sandi dapat membantu menyimpannya dengan lebih teratur.', 'Aktifkan autentikasi dua langkah bila tersedia, dan berhati-hatilah sebelum membuka tautan atau membagikan informasi pribadi.'], art: 'art-tech', symbol: '05'
  },
  {
    category: 'Lingkungan', date: '2025-03-03', title: 'Ruang hijau dan manfaatnya bagi komunitas',
    summary: 'Taman dan ruang terbuka menghadirkan tempat untuk beristirahat dan bertemu.',
    body: ['Ruang hijau dapat menjadi tempat warga berolahraga, bermain, atau sekadar menikmati udara luar. Kehadirannya juga memperindah lingkungan sekitar.', 'Merawat ruang bersama membutuhkan partisipasi semua pihak. Menjaga kebersihan dan menghormati fasilitas umum adalah langkah yang dapat dilakukan bersama.'], art: 'art-nature', symbol: '06'
  }
];

// DOM hanya tersedia ketika halaman dibuka di browser.
if (typeof document !== 'undefined') {
  const grid = document.getElementById('news-grid');
  const search = document.getElementById('search');
  const filters = document.getElementById('filters');
  const count = document.getElementById('result-count');
  const emptyState = document.getElementById('empty-state');
  const dialog = document.getElementById('article-dialog');
  let selectedCategory = 'Semua';

  function formatDate(date) {
    const parts = date.split('-').map(Number);
    return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])));
  }

  function createElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function showArticle(article) {
    document.getElementById('dialog-category').textContent = article.category.toUpperCase();
    document.getElementById('dialog-title').textContent = article.title;
    document.getElementById('dialog-date').textContent = formatDate(article.date);
    const body = document.getElementById('dialog-body');
    body.replaceChildren(...article.body.map(paragraph => createElement('p', '', paragraph)));
    dialog.showModal();
  }

  function createCard(article) {
    const card = createElement('article', 'card');
    const art = createElement('div', 'card-art ' + article.art);
    art.setAttribute('aria-hidden', 'true');
    art.append(createElement('span', '', article.category.toUpperCase()), createElement('strong', '', article.symbol));
    const content = createElement('div', 'card-content');
    const meta = createElement('div', 'card-meta');
    meta.append(createElement('span', '', article.category.toUpperCase()), document.createTextNode('  •  ' + formatDate(article.date)));
    const button = createElement('button', 'read-more', 'Baca selengkapnya →');
    button.type = 'button';
    button.setAttribute('aria-label', 'Baca selengkapnya: ' + article.title);
    button.addEventListener('click', () => showArticle(article));
    content.append(meta, createElement('h3', '', article.title), createElement('p', '', article.summary), button);
    card.append(art, content);
    return card;
  }

  function renderArticles() {
    const query = search.value.trim().toLocaleLowerCase('id');
    const filtered = articles.filter(article => {
      const matchesCategory = selectedCategory === 'Semua' || article.category === selectedCategory;
      const text = [article.title, article.summary, article.category, ...article.body].join(' ').toLocaleLowerCase('id');
      return matchesCategory && text.includes(query);
    });
    grid.replaceChildren(...filtered.map(createCard));
    count.textContent = filtered.length + ' berita ditemukan';
    emptyState.hidden = filtered.length !== 0;
  }

  search.addEventListener('input', renderArticles);
  filters.addEventListener('click', event => {
    const button = event.target.closest('button[data-category]');
    if (!button || !filters.contains(button)) return;
    selectedCategory = button.dataset.category;
    filters.querySelectorAll('button').forEach(item => {
      const active = item === button;
      item.classList.toggle('active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    renderArticles();
  });
  document.getElementById('close-dialog').addEventListener('click', () => dialog.close());
  document.getElementById('year').textContent = new Date().getFullYear();
  renderArticles();
} else {
  console.log('Halaman WartaKini tersedia di index.html dan memerlukan browser.');
}
